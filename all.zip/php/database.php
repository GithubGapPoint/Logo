<?php
$server = "127.0.0.1";
$login = "cr64801_123";
$pass = "28BShZPY";
$name_db = "cr64801_123";

$link = mysqli_connect($server, $login, $pass, $name_db);

if ($link == False)
{
    echo "No";
}
else



?>